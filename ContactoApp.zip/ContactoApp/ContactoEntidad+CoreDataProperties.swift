//
//  ContactoEntidad+CoreDataProperties.swift
//  ContactoApp
//
//  Created by User-UAM on 10/18/24.
//
//

import Foundation
import CoreData

@objc(ContactoEntidad)
public class ContactoEntidad: NSManagedObject {
}

extension ContactoEntidad {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<ContactoEntidad> {
        return NSFetchRequest<ContactoEntidad>(entityName: "ContactoEntidad")
    }

    @NSManaged public var correo: String?
    @NSManaged public var alias: String?
    @NSManaged public var telephone: Int16
}

extension ContactoEntidad : Identifiable {
}
