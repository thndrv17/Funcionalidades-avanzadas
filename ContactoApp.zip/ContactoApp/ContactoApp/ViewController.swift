//
//  ViewController.swift
//  ContactoApp
//
//  Created by User-UAM on 10/18/24.
//

import Contacts
import ContactsUI
import UIKit

struct Person: Codable {
    let name: String
    let id: String
    let sourceData: Data

    var source: CNContact? {
        return try? CNContactVCardSerialization.contacts(with: sourceData).first
    }
}

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, CNContactPickerDelegate {
    
    private let table: UITableView = {
        let table = UITableView()
        table.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        return table
    }()
    
    var models = [Person]() {
        didSet {
            saveContacts()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(table)
        table.frame = view.bounds
        table.dataSource = self
        table.delegate = self
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(didTapAdd))
        
        loadContacts()
    }
    
    @objc func didTapAdd() {
        let vc = CNContactPickerViewController()
        vc.delegate = self
        present(vc, animated: true)
    }
    
    func contactPicker(_ picker: CNContactPickerViewController, didSelect contact: CNContact) {
        let name = contact.givenName + " " + contact.familyName
        let identifier = contact.identifier
        if let data = try? CNContactVCardSerialization.data(with: [contact]) {
            let model = Person(name: name, id: identifier, sourceData: data)
            models.append(model)
            table.reloadData()
        }
    }
    
    func saveContacts() {
        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(models) {
            UserDefaults.standard.set(encoded, forKey: "contacts")
        }
    }
    
    func loadContacts() {
        if let savedData = UserDefaults.standard.data(forKey: "contacts") {
            let decoder = JSONDecoder()
            if let savedContacts = try? decoder.decode([Person].self, from: savedData) {
                models = savedContacts
            }
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return models.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = models[indexPath.row].name
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        guard let contact = models[indexPath.row].source else { return }
        let vc = CNContactViewController(for: contact)
        present(UINavigationController(rootViewController: vc), animated: true)
    }
}


