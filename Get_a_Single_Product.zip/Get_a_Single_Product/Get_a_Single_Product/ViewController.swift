//
//  ViewController.swift
//  Get_a_Single_Product
//
//  Created by User-UAM on 10/20/24.
//

import UIKit

// Modelo para los datos del producto
struct Product: Codable {
    let id: Int
    let title: String
    let description: String
    let price: Double
    let category: String
    let brand: String
    let discountPercentage: Double
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var tableView = UITableView()
    var productList = ["Product 1"]  // Aquí puedes añadir más nombres de productos si es necesario

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupTableView()
    }

    func setupTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        tableView.frame = view.bounds
        view.addSubview(tableView)
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productList.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = productList[indexPath.row]
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)

        let selectedProduct = productList[indexPath.row].lowercased()
        let productVC = ProductViewController()
        productVC.productID = 1  // Aquí se puede cambiar el ID del producto
        let navController = UINavigationController(rootViewController: productVC)
        present(navController, animated: true, completion: nil)
    }
}

class ProductViewController: UIViewController {
    var productID: Int?
    var product: Product?

    let titleLabel = UILabel()
    let descriptionLabel = UILabel()
    let priceLabel = UILabel()
    let categoryLabel = UILabel()
    let brandLabel = UILabel()
    let discountLabel = UILabel()
    let logoutButton = UIButton(type: .system)

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupView()
        fetchProductDetails()
    }

    func setupView() {
        setupLabel(titleLabel)
        setupLabel(descriptionLabel)
        setupLabel(priceLabel)
        setupLabel(categoryLabel)
        setupLabel(brandLabel)
        setupLabel(discountLabel)

        logoutButton.setTitle("Cerrar Sesión", for: .normal)
        logoutButton.addTarget(self, action: #selector(logout), for: .touchUpInside)
        logoutButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(logoutButton)

        setupConstraints()
    }

    func setupLabel(_ label: UILabel) {
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
    }

    func setupConstraints() {
        let padding: CGFloat = 20
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: padding),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding),
            titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding),

            descriptionLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: padding),
            descriptionLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding),
            descriptionLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding),

            priceLabel.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: padding),
            priceLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding),
            priceLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding),

            categoryLabel.topAnchor.constraint(equalTo: priceLabel.bottomAnchor, constant: padding),
            categoryLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding),
            categoryLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding),

            brandLabel.topAnchor.constraint(equalTo: categoryLabel.bottomAnchor, constant: padding),
            brandLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding),
            brandLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding),

            discountLabel.topAnchor.constraint(equalTo: brandLabel.bottomAnchor, constant: padding),
            discountLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding),
            discountLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding),

            logoutButton.topAnchor.constraint(equalTo: discountLabel.bottomAnchor, constant: padding),
            logoutButton.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }

    @objc func logout() {
        UserDefaults.standard.removeObject(forKey: "token")
        dismiss(animated: true, completion: nil)
    }

    func fetchProductDetails() {
        guard let productID = productID else { return }
        let urlString = "https://dummyjson.com/products/\(productID)"
        guard let url = URL(string: urlString) else { return }

        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else { return }
            do {
                let decoder = JSONDecoder()
                self.product = try decoder.decode(Product.self, from: data)
                DispatchQueue.main.async {
                    self.updateView()
                }
            } catch {
                print("Error al decodificar datos del producto: \(error)")
            }
        }
        task.resume()
    }

    func updateView() {
        guard let product = product else { return }
        titleLabel.text = "Title: \(product.title)"
        descriptionLabel.text = "Description: \(product.description)"
        priceLabel.text = "Price: $\(product.price)"
        categoryLabel.text = "Category: \(product.category)"
        brandLabel.text = "Brand: \(product.brand)"
        discountLabel.text = "Discount: \(product.discountPercentage)%"
    }
}
